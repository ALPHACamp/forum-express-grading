const dayjs = require('dayjs')

module.exports = {
  currentYear: () => dayjs().year()
}
